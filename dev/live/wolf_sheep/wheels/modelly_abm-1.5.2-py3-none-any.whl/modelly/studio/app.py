"""The Studio page: the layout of the panels, and ``Page``, which the server shows.

``StudioApp(session)`` is the whole app for one session, which the tests render headless.
``Page`` is what ``modelly studio`` serves: it reads the ``StudioConfig`` from the
environment, loads the model class once per server, and gives each browser tab a session.
"""

from __future__ import annotations

import functools
import warnings

import solara

from modelly.plugins import load_all
from modelly.studio.a11y import LanguageMarker
from modelly.studio.analysis_views import AnalysisTab, ExperimentsTab
from modelly.studio.classroom_view import ClassroomTab
from modelly.studio.config import StudioConfig
from modelly.studio.ensemble_views import AssimilationTab, EnsembleTab
from modelly.studio.everyone import NO_CODE_TABS, BuilderTab, CardTab, CompareTab
from modelly.studio.i18n import direction, set_language, t
from modelly.studio.loader import load_model_class, load_portrayal
from modelly.studio.mapview import MapView
from modelly.studio.panels import ErrorBanner
from modelly.studio.session import StudioSession
from modelly.studio.shell import (
    PANELS,
    Layout,  # noqa: F401 (Solara uses the app module's Layout)
    SidePanel,
    StatusBar,
    TopBar,
)
from modelly.studio.state import use_studio_state
from modelly.studio.tools import LintPanel, LogPanel, ProfilerPanel
from modelly.studio.views import AgentTable, Scrubber, SeriesView, SpaceView
from modelly.studio.workbench import Workbench

TITLE = "Modelly Studio"


@solara.component
def StudioApp(session: StudioSession):
    """The Studio frame for one session: run bar, side panel, tabbed views, status bar."""
    set_language(session.config.language)
    state = use_studio_state(session)
    solara.use_effect(state.drawn.set, [state.revision.value])
    LanguageMarker()
    if direction() == "rtl":
        solara.Style("body, .v-application { direction: rtl; text-align: right; }")
    solara.Title(f"{TITLE}: {session.model_class.__name__}")
    # The open panel and tab: the browser keeps them (see modelly.studio.workbench).
    panel = solara.use_reactive(PANELS[0][0])
    tab = solara.use_reactive(TABS[0][0])
    with solara.Column(classes=["mx-shell"], gap="0"):
        TopBar(state)
        with solara.Row(classes=["mx-body"], gap="0"):
            SidePanel(state, panel)
            Workbench(state, panel, tab)
            Workspace(state, tab)
        StatusBar(state)


@solara.component
def Workspace(state, tab: solara.Reactive[str]):
    """The document tabs, the open tab's views and the timeline under them.

    ``tab`` names the open tab; a name this mode does not show opens the first one.
    """
    tabs = tabs_for(state.session.config.mode)
    names = [name for name, _ in tabs]
    index = names.index(tab.value) if tab.value in names else 0
    with solara.Column(classes=["mx-main"], gap="0"):
        with solara.v.Tabs(
            v_model=index,
            on_v_model=lambda chosen: chosen is None or tab.set(names[chosen]),
            class_="mx-tabs",
            show_arrows=True,
        ):
            for name in names:
                solara.v.Tab(children=[t(name)])
        ErrorBanner(state)
        with solara.Column(classes=["mx-doc"], gap="0"):
            tabs[index][1](state)
        Scrubber(state)


def ModelTab(state):
    """The space view and the reporters plot, side by side."""
    with solara.Columns([1, 1]):
        SpaceView(state)
        SeriesView(state)


TABS = (
    ("Model", ModelTab),
    ("Map", MapView),
    ("Agents", AgentTable),
    ("Compare", CompareTab),
    ("Card", CardTab),
    ("Ensemble", EnsembleTab),
    ("Assimilation", AssimilationTab),
    ("Experiments", ExperimentsTab),
    ("Analysis", AnalysisTab),
    ("Profiler", ProfilerPanel),
    ("Lint", LintPanel),
    ("Log", LogPanel),
    ("Builder", BuilderTab),
    ("Classroom", ClassroomTab),
)
# A plugin's entry point names a component taking the StudioState, like the TABS views.
VIEWS_GROUP = "modelly.studio_views"


@functools.cache
def all_tabs() -> tuple:
    """The built-in tabs, then one per ``modelly.studio_views`` plugin, named after it.

    A view that fails to load is left out with a ``RuntimeWarning``.
    """
    loaded, errors = load_all(VIEWS_GROUP)
    for error in errors.values():
        warnings.warn(f"{error}; Studio shows the other views", RuntimeWarning, 2)
    return TABS + tuple(loaded.items())


def tabs_for(mode: str) -> tuple:
    """Every tab, or in ``"no-code"`` mode the ones of ``NO_CODE_TABS`` and the plugins'."""
    tabs = all_tabs()
    if mode != "no-code":
        return tabs
    plugins = tabs[len(TABS) :]
    return tuple(t for t in TABS if t[0] in NO_CODE_TABS) + plugins


@functools.cache
def _loaded(config_json: str):
    """The config, model class and portrayal, loaded once per server."""
    config = StudioConfig.from_json(config_json)
    portrayal = load_portrayal(config.portrayal) if config.portrayal else None
    return config, load_model_class(config.target), portrayal


def new_session(config: StudioConfig) -> StudioSession:
    """A session for one browser tab."""
    config, model_class, portrayal = _loaded(config.to_json())
    return StudioSession(model_class, config, portrayal)


@solara.component
def Page():
    """The page ``modelly studio`` serves: one session per browser tab."""
    config = StudioConfig.from_environment()
    session = solara.use_memo(lambda: new_session(config), [])
    StudioApp(session)
